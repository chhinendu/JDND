insert into product (product_name, description) values('Mobile', 'Best Mobile');
insert into review (description, product_id, title) values ('Review 1', 1, 'Review');
insert into comment (description, review_id, title) values ('Comment 1', 1, 'Comment');
